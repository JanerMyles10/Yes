<?php
session_start();
session_unset();
session_destroy();

header("Location: http://localhost/Database/"); // Redirect to login page after logging out
exit();
?>
