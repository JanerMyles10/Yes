<?php
session_start();
include('connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize input
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Sanitize user input
    $email = $conn->real_escape_string($email);
    $password = $conn->real_escape_string($password);

    // Check if user exists in the database
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc(); // Fetch the row as $user

        // Verify password
        if (password_verify($password, $user['password'])) {
            // Password is correct, create session
            $_SESSION['email'] = $user['email'];
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role']; // Store the role

            // Redirect based on role
            if ($user['role'] == 'admin') {
                // Redirect to the admin dashboard
                header("Location: dashboard.php");
                exit();
            } elseif ($user['role'] == 'user') {
                // Redirect to the user interface
                header("Location: user.html");
                exit();
            }
        } else {
            echo "Incorrect password!";
        }
    } else {
        echo "No such user found!";
    }

    $conn->close(); // Close the database connection
}
?>
